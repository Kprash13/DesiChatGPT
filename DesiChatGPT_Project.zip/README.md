# DesiChatGPT
A fun Desi-style chatbot using OpenAI's GPT model.
