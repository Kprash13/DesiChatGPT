async function sendMessage() {
  const input = document.getElementById("userInput");
  const message = input.value;
  appendMessage("You", message, "user");
  input.value = "";

  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message })
  });
  const data = await response.json();
  appendMessage("DesiGPT", data.reply, "bot");
}

function appendMessage(sender, text, type) {
  const messages = document.getElementById("messages");
  const msg = document.createElement("div");
  msg.className = "message " + type;
  msg.innerHTML = `<span class="${type}">${sender}:</span> ${text}`;
  messages.appendChild(msg);
}
